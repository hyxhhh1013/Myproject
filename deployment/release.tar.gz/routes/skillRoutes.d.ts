declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=skillRoutes.d.ts.map