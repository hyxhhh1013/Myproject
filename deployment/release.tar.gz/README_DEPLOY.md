# Deployment Guide

This folder contains the compiled application ready for deployment.

## Prerequisites
- Node.js (v18+)
- MySQL Database

## Setup
1. Edit .env file to match your production database and settings.
   - Set \NODE_ENV=production\
   - Set \DATABASE_URL\ to your MySQL connection string.

2. Install Production Dependencies
   \\\ash
   npm install --production
   \\\

3. Run Database Migrations
   \\\ash
   npx prisma migrate deploy
   \\\

4. Start the Server
   \\\ash
   npm start
   \\\

The server will start on the port specified in .env (default 3001) and serve the frontend application.
